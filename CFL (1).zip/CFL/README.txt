﻿# CFL External VNG
su
cd /data/local/tmp/CFL
./cfl_loader
